package com.josemiguel.liquidglasstv.data

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppInfo(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap,
    val banner: ImageBitmap?,
    val category: Int,
    val intent: Intent
)

object AppRepo {
    /** Lee las apps realmente instaladas (Leanback primero, luego launcher normal). */
    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        fun query(cat: String) =
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)

        val all = query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER)
        return all
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
            .mapNotNull { ri ->
                val pkg = ri.activityInfo.packageName
                val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg) ?: return@mapNotNull null
                runCatching {
                    AppInfo(
                        pkg = pkg,
                        label = ri.loadLabel(pm).toString(),
                        icon = ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap(),
                        banner = runCatching {
                            ri.activityInfo.loadBanner(pm)?.toBitmap(256, 144)?.asImageBitmap()
                        }.getOrNull(),
                        category = ri.activityInfo.applicationInfo.category,
                        intent = intent
                    )
                }.getOrNull()
            }
            .sortedBy { it.label.lowercase() }
    }
}
