package com.josemiguel.liquidglasstv.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.josemiguel.liquidglasstv.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun SceneBackground(s: Settings, tod: TimeOfDay) {
    val scene = if (s.bgMode in 1..4) TimeOfDay.entries[s.bgMode - 1] else tod
    val infinite = rememberInfiniteTransition(label = "parallax")
    val drift by infinite.animateFloat(
        -24f, 24f,
        infiniteRepeatable(tween(40000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val custom = rememberCustomBitmap(s.customUri, s.bgMode == 5)

    Box(Modifier.fillMaxSize()) {
        if (custom != null) {
            Image(custom, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Crossfade(
                targetState = scene,
                animationSpec = tween(if (s.animations) 1500 else 0),
                label = "bg"
            ) { sc ->
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        translationX = if (s.animations) drift else 0f  // parallax
                        scaleX = 1.1f; scaleY = 1.1f
                    }
                ) { SceneCanvas(sc) }
            }
        }
        // Velo oscuro para legibilidad (desenfoque progresivo visual)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = 0.15f * s.intensity),
                        Color.Black.copy(alpha = 0.55f * s.intensity.coerceAtMost(1.3f))
                    )
                )
            )
        )
    }
}

@Composable
private fun SceneCanvas(sc: TimeOfDay) {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        when (sc) {
            TimeOfDay.MORNING -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF22304F), Color(0xFFE58C5A), Color(0xFFFFD79A))))
                val c = Offset(w * 0.7f, h * 0.55f)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF3C4), Color(0x00FFE08A)), c, h * 0.4f), h * 0.4f, c)
                drawCircle(Color(0xFFFFF1B8), h * 0.07f, c)
                ridge(h * 0.72f, h * 0.18f, Color(0xFFB8765A), 1f)
                ridge(h * 0.82f, h * 0.20f, Color(0xFF7A4B4F), 2f)
                ridge(h * 0.95f, h * 0.22f, Color(0xFF3B2A3F), 3f)
            }
            TimeOfDay.AFTERNOON -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF3FA7F5), Color(0xFF9ADBFF))), size = Size(w, h * 0.58f))
                drawCircle(Color(0xFFFFF6C8), h * 0.08f, Offset(w * 0.2f, h * 0.2f))
                drawRect(
                    Brush.verticalGradient(listOf(Color(0xFF1FC8C8), Color(0xFF0A8FB5))),
                    Offset(0f, h * 0.58f), Size(w, h * 0.24f)
                )
                drawRect(Color(0xFFF3DDAA), Offset(0f, h * 0.82f), Size(w, h * 0.18f))
                ridge(h * 0.6f, h * 0.06f, Color(0xFF2E7D5B), 4f)
            }
            TimeOfDay.EVENING -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF2B1B4D), Color(0xFFB5446E), Color(0xFFFF8A3D))))
                city(Random(11), h * 0.45f, 0.18f, Color(0xFF3A2459), false)
                city(Random(3), h * 0.55f, 0.35f, Color(0xFF140E26), true)
            }
            TimeOfDay.NIGHT -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF050B1F), Color(0xFF0B1F4A), Color(0xFF16336B))))
                val r = Random(7)
                repeat(170) {
                    drawCircle(
                        Color.White.copy(alpha = 0.35f + 0.65f * r.nextFloat()),
                        1f + 2.2f * r.nextFloat(),
                        Offset(r.nextFloat() * w, r.nextFloat() * h * 0.7f)
                    )
                }
                val m = Offset(w * 0.75f, h * 0.25f)
                drawCircle(Brush.radialGradient(listOf(Color(0x66DDE6FF), Color(0x00DDE6FF)), m, h * 0.3f), h * 0.3f, m)
                drawCircle(Color(0xFFF4F1E4), h * 0.07f, m)
                ridge(h * 0.78f, h * 0.2f, Color(0xFF0E1B3D), 5f)
                ridge(h * 0.93f, h * 0.22f, Color(0xFF060C1E), 6f)
            }
        }
    }
}

private fun DrawScope.ridge(baseY: Float, amp: Float, color: Color, seed: Float) {
    val p = Path()
    p.moveTo(0f, size.height)
    var x = 0f
    while (x <= size.width + 40f) {
        val y = baseY - amp * (0.55f + 0.3f * sin(x * 0.0035f + seed) + 0.15f * sin(x * 0.011f + seed * 2.3f))
        p.lineTo(x, y)
        x += 40f
    }
    p.lineTo(size.width, size.height)
    p.close()
    drawPath(p, color)
}

private fun DrawScope.city(r: Random, topY: Float, heightFrac: Float, color: Color, windows: Boolean) {
    var x = 0f
    while (x < size.width) {
        val bw = 50f + r.nextFloat() * 70f
        val bh = size.height * (heightFrac * 0.5f + heightFrac * r.nextFloat()) + (size.height - topY) * 0.5f
        val top = size.height - bh
        drawRect(color, Offset(x, top), Size(bw, bh))
        if (windows) {
            var wy = top + 14f
            while (wy < size.height - 10f) {
                var wx = x + 8f
                while (wx < x + bw - 14f) {
                    if (r.nextFloat() < 0.35f) {
                        drawRect(Color(0xFFFFC266).copy(alpha = 0.85f), Offset(wx, wy), Size(8f, 12f))
                    }
                    wx += 20f
                }
                wy += 24f
            }
        }
        x += bw + 4f
    }
}

@Composable
private fun rememberCustomBitmap(uri: String, enabled: Boolean): ImageBitmap? {
    val ctx = LocalContext.current
    val state = produceState<ImageBitmap?>(null, uri, enabled) {
        value = if (!enabled || uri.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching { decode(ctx, Uri.parse(uri)) }.getOrNull()
        }
    }
    return state.value
}

private fun decode(ctx: Context, uri: Uri): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 2400) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, opts)?.asImageBitmap()
    }
}
