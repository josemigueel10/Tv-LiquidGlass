package com.josemiguel.liquidglasstv

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.josemiguel.liquidglasstv.data.Settings
import com.josemiguel.liquidglasstv.ui.LauncherApp

class MainActivity : ComponentActivity() {
    private lateinit var settings: Settings
    private var homeSignal by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherApp(settings, homeSignal)
            }
        }
    }

    // Al pulsar el botón HOME del control remoto, volver al inicio.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) homeSignal++
    }
}
