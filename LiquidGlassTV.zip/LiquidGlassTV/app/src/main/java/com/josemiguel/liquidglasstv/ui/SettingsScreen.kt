package com.josemiguel.liquidglasstv.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.josemiguel.liquidglasstv.data.AppInfo
import com.josemiguel.liquidglasstv.data.Settings
import kotlin.math.abs

private val BG_NAMES = listOf("Automático (por hora)", "Amanecer", "Tarde", "Noche", "Madrugada", "Imagen propia")
private val TRANSP = listOf(0.08f, 0.14f, 0.2f, 0.28f, 0.36f)
private val INTENS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f)

private fun cycleF(list: List<Float>, cur: Float): Float {
    val i = list.indexOfFirst { abs(it - cur) < 0.01f }
    return list[(i + 1) % list.size]
}

private fun row(t: String, v: String, a: () -> Unit) = Triple(t, v, a)
private fun pct(v: Float) = "${(v * 100).toInt()}%"
private fun hh(h: Int) = "%02d:00".format(h)
private fun onOff(b: Boolean) = if (b) "Activado" else "Desactivado"

@Composable
fun SettingsScreen(s: Settings, accent: Color, apps: List<AppInfo>) {
    val ctx = LocalContext.current
    var page by remember { mutableStateOf("main") }
    var showName by remember { mutableStateOf(false) }
    BackHandler(enabled = page != "main") { page = "main" }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            s.setCustomUri(uri.toString())
            s.setBgMode(5)
        }
    }

    if (page == "fav") {
        FavoritesPage(s, accent, apps)
        return
    }

    LazyColumn(
        Modifier.widthIn(max = 900.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
    ) {
        val rows = listOf(
            row("Nombre del saludo", s.name) { showName = true },
            row("Fondo", BG_NAMES[s.bgMode.coerceIn(0, 5)]) { s.setBgMode((s.bgMode + 1) % BG_NAMES.size) },
            row("Elegir imagen propia", if (s.customUri.isBlank()) "Ninguna" else "Seleccionada") {
                try { picker.launch(arrayOf("image/*")) }
                catch (e: ActivityNotFoundException) {
                    Toast.makeText(ctx, "Este dispositivo no tiene selector de archivos", Toast.LENGTH_LONG).show()
                }
            },
            row("Quitar imagen propia", "") { s.setCustomUri(""); if (s.bgMode == 5) s.setBgMode(0) },
            row("Animaciones", onOff(s.animations)) { s.setAnimations(!s.animations) },
            row("Efectos Liquid Glass", onOff(s.glass)) { s.setGlass(!s.glass) },
            row("Transparencia", pct(s.transparency)) { s.setTransparency(cycleF(TRANSP, s.transparency)) },
            row("Intensidad de efectos", pct(s.intensity)) { s.setIntensity(cycleF(INTENS, s.intensity)) },
            row("Formato de hora", if (s.hour24) "24 horas" else "12 horas") { s.setHour24(!s.hour24) },
            row("Sonidos", onOff(s.sounds)) { s.setSounds(!s.sounds) },
            row("Inicio de la mañana", hh(s.morningStart)) {
                s.setMorningStart(if (s.morningStart >= 10) 4 else s.morningStart + 1)
            },
            row("Inicio de la tarde", hh(s.afternoonStart)) {
                s.setAfternoonStart(if (s.afternoonStart >= 16) 11 else s.afternoonStart + 1)
            },
            row("Inicio de la noche", hh(s.eveningStart)) {
                s.setEveningStart(if (s.eveningStart >= 20) 17 else s.eveningStart + 1)
            },
            row("Inicio de la madrugada", hh(s.nightStart)) {
                s.setNightStart(if (s.nightStart >= 23) 20 else s.nightStart + 1)
            },
            row("Aplicaciones favoritas y orden", "Abrir") { page = "fav" }
        )
        items(rows) { (title, value, action) ->
            GlassCard(s, accent, Modifier.fillMaxWidth().height(58.dp), onClick = action) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Text(value, color = Color.White.copy(alpha = 0.8f), fontSize = 16.sp)
                }
            }
        }
    }

    if (showName) {
        var text by remember { mutableStateOf(s.name) }
        AlertDialog(
            onDismissRequest = { showName = false },
            title = { Text("Nombre del saludo") },
            text = { TextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { if (text.isNotBlank()) s.setName(text.trim()); showName = false }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { showName = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun FavoritesPage(s: Settings, accent: Color, apps: List<AppInfo>) {
    val favs = s.favorites.mapNotNull { p -> apps.find { it.pkg == p } }
    val others = apps.filter { it.pkg !in s.favorites }
    LazyColumn(
        Modifier.widthIn(max = 900.dp).fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
    ) {
        items(favs + others) { app ->
            val isFav = app.pkg in s.favorites
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(app.icon, null, Modifier.size(40.dp))
                Spacer(Modifier.width(14.dp))
                Text(app.label, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                if (isFav) {
                    GlassCard(s, accent, Modifier.size(56.dp, 48.dp), onClick = { s.moveFavoriteUp(app.pkg) }) {
                        Text("▲", color = Color.White)
                    }
                    Spacer(Modifier.width(10.dp))
                }
                GlassCard(s, accent, Modifier.size(120.dp, 48.dp), onClick = { s.toggleFavorite(app.pkg) }) {
                    Text(if (isFav) "★ Quitar" else "☆ Añadir", color = Color.White, fontSize = 15.sp)
                }
            }
        }
    }
}
