package com.josemiguel.liquidglasstv.ui

import androidx.compose.ui.graphics.Color
import com.josemiguel.liquidglasstv.data.Settings

enum class TimeOfDay(val accent: Color) {
    MORNING(Color(0xFFFFC46B)),
    AFTERNOON(Color(0xFF7FE0FF)),
    EVENING(Color(0xFFFF8A5C)),
    NIGHT(Color(0xFF8AA8FF));

    fun greeting(name: String): String = when (this) {
        MORNING -> "¡Buenos días, $name! ☀️"
        AFTERNOON -> "¡Buenas tardes, $name! 🌤️"
        EVENING -> "¡Buenas noches, $name! 🌅"
        NIGHT -> "¡Que descanses, $name! 🌙"
    }

    val subtitle: String
        get() = when (this) {
            MORNING -> "Que tengas un excelente día"
            AFTERNOON -> "Disfruta cada momento"
            EVENING -> "Relájate y disfruta tu noche"
            NIGHT -> "Es hora de descansar. Hasta mañana"
        }
}

/** Horarios por defecto: 6–11:59 / 12–17:59 / 18–20:59 / 21–05:59 (configurables). */
fun timeOfDayFor(hour: Int, s: Settings): TimeOfDay = when {
    hour >= s.nightStart || hour < s.morningStart -> TimeOfDay.NIGHT
    hour >= s.eveningStart -> TimeOfDay.EVENING
    hour >= s.afternoonStart -> TimeOfDay.AFTERNOON
    else -> TimeOfDay.MORNING
}
