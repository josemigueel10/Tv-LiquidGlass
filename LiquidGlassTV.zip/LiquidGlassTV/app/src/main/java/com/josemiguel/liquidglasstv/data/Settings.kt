package com.josemiguel.liquidglasstv.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Ajustes guardados localmente (SharedPreferences) y observables desde Compose. */
class Settings(context: Context) {
    private val sp: SharedPreferences =
        context.getSharedPreferences("jm_launcher", Context.MODE_PRIVATE)

    private fun update(block: SharedPreferences.Editor.() -> Unit) {
        sp.edit().apply(block).apply()
    }

    var name by mutableStateOf(sp.getString("name", "José Miguel") ?: "José Miguel")
        private set
    /** 0 = automático por hora, 1..4 = Amanecer/Tarde/Noche/Madrugada, 5 = imagen propia */
    var bgMode by mutableStateOf(sp.getInt("bgMode", 0))
        private set
    var customUri by mutableStateOf(sp.getString("customUri", "") ?: "")
        private set
    var animations by mutableStateOf(sp.getBoolean("animations", true))
        private set
    var glass by mutableStateOf(sp.getBoolean("glass", true))
        private set
    var transparency by mutableStateOf(sp.getFloat("transparency", 0.2f))
        private set
    var intensity by mutableStateOf(sp.getFloat("intensity", 1f))
        private set
    var hour24 by mutableStateOf(sp.getBoolean("hour24", true))
        private set
    var sounds by mutableStateOf(sp.getBoolean("sounds", true))
        private set
    var morningStart by mutableStateOf(sp.getInt("morningStart", 6))
        private set
    var afternoonStart by mutableStateOf(sp.getInt("afternoonStart", 12))
        private set
    var eveningStart by mutableStateOf(sp.getInt("eveningStart", 18))
        private set
    var nightStart by mutableStateOf(sp.getInt("nightStart", 21))
        private set
    var favorites by mutableStateOf(
        sp.getString("favs", null)?.split(",")?.filter { it.isNotBlank() } ?: DEFAULT_FAVS
    )
        private set

    fun setName(v: String) { name = v; update { putString("name", v) } }
    fun setBgMode(v: Int) { bgMode = v; update { putInt("bgMode", v) } }
    fun setCustomUri(v: String) { customUri = v; update { putString("customUri", v) } }
    fun setAnimations(v: Boolean) { animations = v; update { putBoolean("animations", v) } }
    fun setGlass(v: Boolean) { glass = v; update { putBoolean("glass", v) } }
    fun setTransparency(v: Float) { transparency = v; update { putFloat("transparency", v) } }
    fun setIntensity(v: Float) { intensity = v; update { putFloat("intensity", v) } }
    fun setHour24(v: Boolean) { hour24 = v; update { putBoolean("hour24", v) } }
    fun setSounds(v: Boolean) { sounds = v; update { putBoolean("sounds", v) } }
    fun setMorningStart(v: Int) { morningStart = v; update { putInt("morningStart", v) } }
    fun setAfternoonStart(v: Int) { afternoonStart = v; update { putInt("afternoonStart", v) } }
    fun setEveningStart(v: Int) { eveningStart = v; update { putInt("eveningStart", v) } }
    fun setNightStart(v: Int) { nightStart = v; update { putInt("nightStart", v) } }

    private fun saveFavs(list: List<String>) {
        favorites = list
        update { putString("favs", list.joinToString(",")) }
    }

    fun toggleFavorite(pkg: String) {
        saveFavs(if (pkg in favorites) favorites - pkg else favorites + pkg)
    }

    fun moveFavoriteUp(pkg: String) {
        val i = favorites.indexOf(pkg)
        if (i > 0) {
            val m = favorites.toMutableList()
            m[i] = m[i - 1]; m[i - 1] = pkg
            saveFavs(m)
        }
    }

    companion object {
        /** Solo se muestran las que estén realmente instaladas. */
        val DEFAULT_FAVS = listOf(
            "com.apple.atve.androidtv.appletv",
            "com.google.android.youtube.tv",
            "com.netflix.ninja",
            "com.disney.disneyplus",
            "com.amazon.amazonvideo.livingroom",
            "com.wbd.stream",
            "com.spotify.tv.android"
        )
    }
}
