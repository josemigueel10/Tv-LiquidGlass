package com.josemiguel.liquidglasstv.ui

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.josemiguel.liquidglasstv.data.AppInfo
import com.josemiguel.liquidglasstv.data.AppRepo
import com.josemiguel.liquidglasstv.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Section(val label: String, val emoji: String) {
    HOME("Inicio", "🏠"),
    MOVIES("Películas", "🎬"),
    SERIES("Series", "📺"),
    APPS("Aplicaciones", "🧩"),
    GAMES("Juegos", "🎮"),
    MUSIC("Música", "🎵"),
    SEARCH("Buscar", "🔍"),
    SETTINGS("Configuración", "⚙️")
}

@Composable
fun LauncherApp(s: Settings, homeSignal: Int) {
    val ctx = LocalContext.current
    val apps by rememberInstalledApps()
    var section by remember { mutableStateOf(Section.HOME) }
    LaunchedEffect(homeSignal) { section = Section.HOME }
    val now by rememberMinuteClock()
    val tod = timeOfDayFor(now.hour, s)
    val accent = tod.accent
    val dur = if (s.animations) 350 else 0

    BackHandler(enabled = section != Section.HOME) { section = Section.HOME }

    val launch: (AppInfo) -> Unit = { app ->
        try {
            ctx.startActivity(Intent(app.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
    SceneBackground(s, tod)
    Column(
        Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NavBar(s, accent, section, Modifier.weight(1f)) { sec ->
                if (sec == Section.SEARCH) openSearch(ctx) else section = sec
            }
            Spacer(Modifier.width(24.dp))
            Clock(s, now)
        }
        Spacer(Modifier.height(18.dp))
        AnimatedContent(
            targetState = section,
            transitionSpec = {
                (fadeIn(tween(dur)) + slideInVertically(tween(dur)) { it / 20 }) togetherWith fadeOut(tween(dur / 2))
            },
            label = "section"
        ) { sec ->
            when (sec) {
                Section.HOME -> HomeScreen(s, accent, tod, apps, launch) { section = Section.APPS }
                Section.MOVIES, Section.SERIES ->
                    AppGrid(s, accent, apps.filter { it.category == ApplicationInfo.CATEGORY_VIDEO }, launch)
                Section.APPS -> AppGrid(s, accent, apps, launch)
                Section.GAMES ->
                    AppGrid(s, accent, apps.filter { it.category == ApplicationInfo.CATEGORY_GAME }, launch)
                Section.MUSIC ->
                    AppGrid(s, accent, apps.filter { it.category == ApplicationInfo.CATEGORY_AUDIO }, launch)
                Section.SETTINGS -> SettingsScreen(s, accent, apps)
                Section.SEARCH -> Unit
            }
        }
    }
    }
}

private fun openSearch(ctx: Context) {
    val tries = listOf(Intent(Intent.ACTION_ASSIST), Intent("android.search.action.GLOBAL_SEARCH"))
    for (i in tries) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
        } catch (_: ActivityNotFoundException) {
        }
    }
    Toast.makeText(ctx, "Búsqueda no disponible en este dispositivo", Toast.LENGTH_SHORT).show()
}

@Composable
private fun NavBar(
    s: Settings, accent: Color, current: Section, modifier: Modifier, onSelect: (Section) -> Unit
) {
    LazyRow(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 14.dp, horizontal = 8.dp)
    ) {
        items(Section.entries.toList()) { sec ->
            val selected = sec == current
            GlassCard(
                s, accent,
                Modifier.height(46.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(23.dp),
                onClick = { onSelect(sec) }
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(sec.emoji, fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        sec.label, fontSize = 15.sp, color = Color.White,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun Clock(s: Settings, now: LocalDateTime) {
    val es = Locale("es", "ES")
    val time = now.format(DateTimeFormatter.ofPattern(if (s.hour24) "HH:mm" else "h:mm a", es))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", es))
        .replaceFirstChar { it.uppercase() }
    Column(horizontalAlignment = Alignment.End) {
        Text(time, fontSize = 34.sp, fontWeight = FontWeight.Light, color = Color.White)
        Text(date, fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
    }
}

@Composable
private fun HomeScreen(
    s: Settings, accent: Color, tod: TimeOfDay, apps: List<AppInfo>,
    launch: (AppInfo) -> Unit, showAll: () -> Unit
) {
    val dur = if (s.animations) 800 else 0
    Column {
        AnimatedContent(
            targetState = tod to s.name,
            transitionSpec = {
                (fadeIn(tween(dur)) + slideInVertically(tween(dur)) { it / 4 }) togetherWith fadeOut(tween(dur / 2))
            },
            label = "greeting"
        ) { (t, n) ->
            Column {
                Text(t.greeting(n), fontSize = 44.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(t.subtitle, fontSize = 20.sp, color = Color.White.copy(alpha = 0.85f))
            }
        }
        Spacer(Modifier.height(28.dp))
        SectionTitle("Favoritas")
        val favs = s.favorites.mapNotNull { p -> apps.find { it.pkg == p } }
        val first = remember { FocusRequester() }
        LaunchedEffect(favs.isNotEmpty()) { runCatching { first.requestFocus() } }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(vertical = 26.dp, horizontal = 12.dp)
        ) {
            items(favs.size) { i ->
                AppCard(s, accent, favs[i], Modifier.size(190.dp, 120.dp), if (i == 0) first else null, launch)
            }
            item {
                GlassCard(s, accent, Modifier.size(190.dp, 120.dp), if (favs.isEmpty()) first else null, onClick = showAll) {
                    Text("Todas las\naplicaciones", color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        SectionTitle("Continuar viendo")
        Spacer(Modifier.height(12.dp))
        // Android no permite a un launcher leer el progreso de otras apps, así que no se inventan datos.
        Box2(s, accent)
    }
}

@Composable
private fun Box2(s: Settings, accent: Color) {
    Box(
        Modifier.fillMaxWidth().height(90.dp)
            .glass(s, accent, false),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "Aquí aparecerá tu contenido en progreso cuando una app compatible lo comparta.",
            color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp
        )
    }
}

@Composable
private fun SectionTitle(t: String) =
    Text(t, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Color.White)

@Composable
private fun AppCard(
    s: Settings, accent: Color, app: AppInfo, modifier: Modifier,
    fr: FocusRequester?, launch: (AppInfo) -> Unit
) {
    GlassCard(s, accent, modifier, fr, onClick = { launch(app) }) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(app.icon, app.label, Modifier.size(62.dp))
            Spacer(Modifier.height(8.dp))
            Text(
                app.label, color = Color.White, fontSize = 15.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 10.dp)
            )
        }
    }
}

@Composable
private fun AppGrid(s: Settings, accent: Color, apps: List<AppInfo>, launch: (AppInfo) -> Unit) {
    if (apps.isEmpty()) {
        Text(
            "No hay aplicaciones de esta categoría instaladas.",
            color = Color.White.copy(alpha = 0.8f), fontSize = 18.sp, modifier = Modifier.padding(24.dp)
        )
        return
    }
    LazyVerticalGrid(
        GridCells.Adaptive(180.dp),
        contentPadding = PaddingValues(18.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items(apps) { app -> AppCard(s, accent, app, Modifier.height(120.dp), null, launch) }
    }
}

@Composable
private fun rememberInstalledApps(): State<List<AppInfo>> {
    val ctx = LocalContext.current
    var reload by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { reload++ }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    return produceState(emptyList<AppInfo>(), reload) {
        value = withContext(Dispatchers.IO) { AppRepo.load(ctx) }
    }
}

/** Hora local del televisor, actualizada en cada cambio de minuto (sin reiniciar). */
@Composable
private fun rememberMinuteClock(): State<LocalDateTime> =
    produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L) + 50L)
        }
    }
