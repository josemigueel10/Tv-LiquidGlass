package com.josemiguel.liquidglasstv.ui

import android.view.SoundEffectConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.josemiguel.liquidglasstv.data.Settings

/** Efecto Liquid Glass: cristal translúcido, borde luminoso, reflejo diagonal y brillo al enfocar. */
fun Modifier.glass(
    s: Settings,
    accent: Color,
    focused: Boolean,
    shape: Shape = RoundedCornerShape(22.dp)
): Modifier {
    val glow = if (focused) Modifier.drawBehind {
        drawRoundRect(
            brush = Brush.radialGradient(
                listOf(accent.copy(alpha = 0.55f * s.intensity.coerceAtMost(1.3f)), Color.Transparent),
                center, size.maxDimension * 0.85f
            ),
            topLeft = Offset(-24f, -24f),
            size = Size(size.width + 48f, size.height + 48f),
            cornerRadius = CornerRadius(40f)
        )
    } else Modifier

    if (!s.glass) {
        return this.then(glow).clip(shape)
            .background(Color(0xFF1E1E24))
            .border(if (focused) 3.dp else 1.dp, Color.White.copy(alpha = if (focused) 0.9f else 0.12f), shape)
    }
    val a = s.transparency
    return this.then(glow)
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = a + 0.10f), Color.White.copy(alpha = a * 0.5f))))
        .drawWithContent {
            drawContent()
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.10f * s.intensity), Color.Transparent),
                    start = Offset.Zero, end = Offset(size.width, size.height * 0.7f)
                ),
                size = Size(size.width, size.height * 0.5f)
            )
        }
        .border(
            if (focused) 3.dp else 1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = if (focused) 0.95f else 0.45f),
                    Color.White.copy(alpha = 0.08f),
                    Color.White.copy(alpha = 0.30f)
                )
            ),
            shape
        )
}

fun playSound(view: android.view.View, s: Settings, id: Int = SoundEffectConstants.CLICK) {
    if (s.sounds) view.playSoundEffect(id)
}

/** Tarjeta enfocable con control remoto: escala, elevación, brillo y sonido suave. */
@Composable
fun GlassCard(
    s: Settings,
    accent: Color,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    shape: Shape = RoundedCornerShape(22.dp),
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (focused) 1f + 0.08f * s.intensity else 1f,
        tween(if (s.animations) 220 else 0), label = "scale"
    )
    val view = LocalView.current
    Box(
        modifier
            .zIndex(if (focused) 1f else 0f)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onFocusChanged {
                if (it.isFocused && !focused) playSound(view, s, SoundEffectConstants.NAVIGATION_RIGHT)
                focused = it.isFocused
            }
            .glass(s, accent, focused, shape)
            .clickable { playSound(view, s); onClick() },
        contentAlignment = Alignment.Center,
        content = content
    )
}
