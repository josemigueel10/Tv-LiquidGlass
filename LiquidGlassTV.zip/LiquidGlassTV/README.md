# JOSÉ MIGUEL – LIQUID GLASS TV (launcher Android TV)

## Compilar en GitHub (sin instalar nada)
1. Crea un repositorio nuevo en GitHub y sube TODO el contenido de esta carpeta
   (incluida la carpeta oculta `.github`).
2. Ve a la pestaña **Actions** → workflow **Build APK** (se ejecuta solo al subir; o "Run workflow").
3. Al terminar, abre la ejecución y descarga el artefacto **LiquidGlassTV-apk** (contiene `app-debug.apk`).

## Compilar en Android Studio
Abrir la carpeta → Sync → Build > Build APK(s).

## Instalar en Android TV / TV Box
- Activa Opciones de desarrollador y Depuración USB/ADB, o permite "fuentes desconocidas".
- `adb connect IP_DE_LA_TV:5555` y `adb install app-debug.apk`
  (o copia el APK a un USB e instálalo con un gestor de archivos).
- Abre "José Miguel – Liquid Glass TV" una vez.
- Pulsa el botón HOME: Android preguntará qué launcher usar → elige este → "Siempre".
  Si tu TV no lo pregunta: Ajustes > Aplicaciones > Aplicaciones predeterminadas > Pantalla de inicio.
